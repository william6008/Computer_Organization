module ALU (
    input [3:0] ALUctl,
    input signed [31:0] pc,
    input isUtype,
    input signed [31:0] A,B,
    output reg signed [31:0] ALUOut,
    output zero
);
    // ALU has two operand, it execute different operator based on ALUctl wire
    // output zero is for determining taking branch or not (or you can change the design as you wish)

    // TODO: implement your ALU here
    // Hint: you can use operator to implement
    always @(*) begin
        case(ALUctl)
            4'b0000: ALUOut = A & B;
            4'b0001: ALUOut = A | B;
            4'b0010:
                case(isUtype) 
                    1'b0: ALUOut = A + B;
                    1'b1: ALUOut = pc + B;
                endcase
            4'b0110: ALUOut = A - B;
            4'b0111: ALUOut = (A<B)? 1:0;
            default: ALUOut = {32{1'bx}};
        endcase
        zero = (ALUOut == 0)? 1:0;
    end
    
endmodule

